package in.ineuron.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySqlUtil {
	
	//2. Establish the connection
	static String url="jdbc:mysql://localhost:3306/mydb";
	static String username="root";
	static String password="root@123";
	static Connection connection;
	
	public static Connection getConnection() throws SQLException {
		connection=DriverManager.getConnection(url, username, password);
		return connection;
	}
	
	public static void cleanUp(Connection con, ResultSet resultSet, Statement stmt) throws SQLException {
		if(con != null)
			con.close();
		if(resultSet != null)
			resultSet.close();
		if(stmt != null)
			stmt.close();
	}
	
}
