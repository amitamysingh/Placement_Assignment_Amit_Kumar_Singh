package in.ineuron.main;

import java.io.IOException;

public class CRUDApp {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Welcome to MySQL CRUD App");
		CRUDOperations crudOperation=new CRUDOperations();
		crudOperation.selectOperation();
		
	}

}
