package in.ineuron.main;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.io.*;

public class CRUDOperations {
	
	Connection connection=null;
	ResultSet resultSet=null;
	PreparedStatement pstmt=null;
	Scanner sc=null;
	
	
	/*
	 * 
	 * Important learning:
	 * When we call scanner.close() at the end of every operation
	 * (insert,read,update,delete)
	 * System.in -> also gets closed and hence, on calling isContinue() 
	 * while taking user input (scanner.next()) "we get NoSuchElementFoundException"
	 * Hence, we commented out scanner.close() at all the operation and only kept it
	 * at finally block of isContinue, so whenever all the operations end and 
	 * the program is going to terminate, scanner resource will be closed at that time
	 * 
	 */
	
	public void selectOperation() {
		sc=new Scanner(System.in);
		
		System.out.println("Select what operation you need to perform on DB");
		System.out.println("Enter '1' for insert operation");
		System.out.println("Enter '2' for update operation");
		System.out.println("Enter '3' for delete operation");
		System.out.println("Enter '4' for search operation");
		
		System.out.println(sc.hasNext());
		int response=sc.nextInt();
		
		if(response == 1) {
			insertDetails();
		}
		else if(response == 2) {
			updateDetails();
		}
		else if(response == 3) {
			deleteDetails();
		}
		else if(response == 4) {
			readDetails();
		}
		else {
			
			System.out.println("Unknown Input");
			isContinue();
		}
		
		isContinue();
		
		
		
	}
	
	public void isContinue(){
		
		String continueResponse;
		
		InputStreamReader r=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(r);
		//sc=new Scanner(System.in);
		System.out.println("Do you want to Continue? Y/N::");
		
		//System.out.println(System.in.available());
		
		//continueResponse= sc.nextInt();
		try {
			continueResponse= br.readLine();
			if(continueResponse.equalsIgnoreCase("y")) {
				selectOperation();
			}
			else if(continueResponse.equalsIgnoreCase("n")) {
				System.exit(0);
			}
			else {
				System.out.println("Unknown input");
				isContinue();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			sc.close();
		}
		
		
		
		}
	
	
	public void insertDetails() {
		try {
			connection=MySqlUtil.getConnection();
			
			String insertQuery="insert into student (`sname`,`sage`,`saddress`) values(?,?,?)";
			
			if(connection != null)
				pstmt=connection.prepareStatement(insertQuery);
				
			if(pstmt != null) {
				sc=new Scanner(System.in);
				
				System.out.println("Enter the student name:: ");
				String sname=sc.next();
				System.out.println("Enter the student age:: ");
				int sage=sc.nextInt();
				System.out.println("Enter the student address:: ");
				String saddress=sc.next();
				
				pstmt.setString(1, sname);
				pstmt.setInt(2, sage);
				pstmt.setString(3, saddress);
				
				int rowCount=pstmt.executeUpdate();
				System.out.println("No. of rows affected:: "+rowCount);
			}
			
		}catch(SQLException se) {
			System.out.println("SQL Exception found in insert statement");
			se.printStackTrace();
		}catch(Exception e) {
			System.out.println("Exception found in insert statement");
			e.printStackTrace();
		}finally {
			try {
				//sc.close();
				MySqlUtil.cleanUp(connection, null, pstmt);
			}catch(SQLException se) {
				System.out.println("SQL Exception found while cleaning up");
				se.printStackTrace();
			}
			catch(Exception e) {
				System.out.println("Exception found while cleaning up");
				e.printStackTrace();
		}
		}
	}
	
	public void updateDetails() {
		try {
			connection=MySqlUtil.getConnection();
			
			String updateQuery="update student set sname=?, sage=?, saddress=? where stdid=?";
			
			if(connection != null)
				pstmt=connection.prepareStatement(updateQuery);
				
			if(pstmt != null) {
				sc=new Scanner(System.in);
				
				System.out.println("Enter the student id to be updated:: ");
				int sid=sc.nextInt();
				System.out.println("Enter the student name to be updated:: ");
				String sname=sc.next();
				System.out.println("Enter the student age to be updated:: ");
				int sage=sc.nextInt();
				System.out.println("Enter the student address to be updated:: ");
				String saddress=sc.next();
				
				pstmt.setString(1, sname);
				pstmt.setInt(2, sage);
				pstmt.setString(3, saddress);
				pstmt.setInt(4, sid);
				
				int rowCount=pstmt.executeUpdate();
				System.out.println("No. of rows affected:: "+rowCount);
			}
			
		}catch(SQLException se) {
			System.out.println("SQL Exception found in insert statement");
			se.printStackTrace();
		}catch(Exception e) {
			System.out.println("Exception found in insert statement");
			e.printStackTrace();
		}finally {
			try {
				//sc.close();
				MySqlUtil.cleanUp(connection, null, pstmt);
			}catch(SQLException se) {
				System.out.println("SQL Exception found while cleaning up");
				se.printStackTrace();
			}
			catch(Exception e) {
				System.out.println("Exception found while cleaning up");
				e.printStackTrace();
		}
		}
	}
	
	public void deleteDetails() {
		try {
			connection=MySqlUtil.getConnection();
			
			String deleteQuery="delete from student where stdid=?";
			
			if(connection != null)
				pstmt=connection.prepareStatement(deleteQuery);
				
			if(pstmt != null) {
				sc=new Scanner(System.in);
				
				System.out.println("Enter the student id to be deleted:: ");
				int sid=sc.nextInt();
				
				pstmt.setInt(1, sid);
				
				int rowCount=pstmt.executeUpdate();
				System.out.println("No. of rows affected:: "+rowCount);
			}
			
		}catch(SQLException se) {
			System.out.println("SQL Exception found in insert statement");
			se.printStackTrace();
		}catch(Exception e) {
			System.out.println("Exception found in insert statement");
			e.printStackTrace();
		}finally {
			try {
				//sc.close();
				MySqlUtil.cleanUp(connection, null, pstmt);
			}catch(SQLException se) {
				System.out.println("SQL Exception found while cleaning up");
				se.printStackTrace();
			}
			catch(Exception e) {
				System.out.println("Exception found while cleaning up");
				e.printStackTrace();
		}
		}
	}
	
	public void readDetails() {
		try {
			connection=MySqlUtil.getConnection();
			
			String selectQuery="select sname,sage,saddress from student where stdid=?";
			
			if(connection != null)
				pstmt=connection.prepareStatement(selectQuery);
				
			if(pstmt != null) {
				sc=new Scanner(System.in);
				
				System.out.println("Enter the student id to be searched:: ");
				System.out.println(sc.hasNext());
				int sid=sc.nextInt();
				//System.out.println(sc.hasNext());
				
				pstmt.setInt(1, sid);
				
				System.out.println("sname \t sage \t saddress");
				resultSet=pstmt.executeQuery();
				
				while(resultSet.next()) {
					String sname=resultSet.getString(1);
					int sage=resultSet.getInt(2);
					String saddress = resultSet.getString(3);
					
					System.out.println(sname+" \t "+sage+" \t "+saddress);
				}
			}
		}			
			catch(SQLException se) {
				System.out.println("SQL Exception found in insert statement");
				se.printStackTrace();
			}catch(Exception e) {
				System.out.println("Exception found in insert statement");
				e.printStackTrace();
			}finally {
				try {
					//sc.close();
					MySqlUtil.cleanUp(connection, resultSet, pstmt);
				}catch(SQLException se) {
					System.out.println("SQL Exception found while cleaning up");
					se.printStackTrace();
				}
				catch(Exception e) {
					System.out.println("Exception found while cleaning up");
					e.printStackTrace();
				}
			}
	}
}
