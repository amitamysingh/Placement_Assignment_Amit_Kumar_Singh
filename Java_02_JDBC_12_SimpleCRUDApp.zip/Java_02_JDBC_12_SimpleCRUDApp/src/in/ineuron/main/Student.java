package in.ineuron.main;

public class Student {

}
