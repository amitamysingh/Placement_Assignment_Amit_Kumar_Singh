package in.ineuron.main;

class ShapesMethodCalls{
	
	//Reference is of Parent Type, hence, parent class will take form of different objects
	public void callCalculationMethods(Shapes shape) {
		shape.calculatePerimeter();
		shape.calculateArea();
	}
}


public class ShapesCalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ShapesMethodCalls methodCalls=new ShapesMethodCalls();
		
		//Parent type reference and child type object
		Shapes rectangle1=new ShapeImpl_01_Rectangle(5,4);
		Shapes circle1=new ShapeImpl_02_Circle(7);
		Shapes square1=new ShapeImpl_03_Square(5);
		Shapes triangle1=new ShapeImpl_04_Triangle(6, 8, 8);
		
		
		//We need to call one method per object instead of calling different methods for different object
		//Here parent class will take form of different child objects => Polymorphism
		methodCalls.callCalculationMethods(rectangle1);
		methodCalls.callCalculationMethods(circle1);
		methodCalls.callCalculationMethods(square1);
		methodCalls.callCalculationMethods(triangle1);
	}

}
