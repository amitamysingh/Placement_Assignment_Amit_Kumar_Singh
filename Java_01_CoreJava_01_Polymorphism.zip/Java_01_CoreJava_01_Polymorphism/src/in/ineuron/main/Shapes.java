package in.ineuron.main;

public interface Shapes {
	
	public void calculatePerimeter();
	public void calculateArea();
	
}
