package in.ineuron.main;

class ShapeImpl_03_Square implements Shapes {
	
	private double side;
	
	public ShapeImpl_03_Square(double side) {
		this.side=side;
	}
	
	@Override
	public void calculatePerimeter() {
		// TODO Auto-generated method stub
		System.out.println("Perimeter of the square is:: "+ 4*side);
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
		System.out.println("Area of the square is:: "+ side*side);
		
	}

}
