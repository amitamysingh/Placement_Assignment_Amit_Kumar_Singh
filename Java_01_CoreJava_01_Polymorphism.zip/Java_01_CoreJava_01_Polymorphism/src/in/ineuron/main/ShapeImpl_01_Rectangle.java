package in.ineuron.main;

class ShapeImpl_01_Rectangle implements Shapes {
	
	private double length;
	private double breadth;
	
	public ShapeImpl_01_Rectangle(double length, double breadth) {
		this.length=length;
		this.breadth=breadth;
	}
	
	@Override
	public void calculatePerimeter() {
		// TODO Auto-generated method stub
		System.out.println("Perimeter of the rectangle is:: "+ 2*(length+breadth));
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
		System.out.println("Perimeter of the rectangle is:: "+ length*breadth);
		
	}

}
