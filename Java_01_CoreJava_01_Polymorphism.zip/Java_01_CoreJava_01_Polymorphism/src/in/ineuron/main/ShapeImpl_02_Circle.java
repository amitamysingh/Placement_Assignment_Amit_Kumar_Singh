package in.ineuron.main;

public class ShapeImpl_02_Circle implements Shapes {
	
	private double radius;
	private final double pi=3.141;
	
	public ShapeImpl_02_Circle(double radius) {
		this.radius=radius;
	}
	@Override
	public void calculatePerimeter() {
		// TODO Auto-generated method stub
		System.out.println("The perimeter of the circle is:: "+2*pi*radius);
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		System.out.println("The area of the circle is:: "+pi*radius*radius);

	}

}
