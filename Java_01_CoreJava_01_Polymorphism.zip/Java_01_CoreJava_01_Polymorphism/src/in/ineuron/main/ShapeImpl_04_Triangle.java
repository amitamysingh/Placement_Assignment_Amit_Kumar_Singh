package in.ineuron.main;

class ShapeImpl_04_Triangle implements Shapes {
	
	//The following program is for Isometric/Equilateral triangle
	private double side;
	private double base;
	private double height;
	
	
	public ShapeImpl_04_Triangle(double side,double base, double height) {
		this.side=side;
		this.base=base;
		this.height=height;
	}
	
	@Override
	public void calculatePerimeter() {
		
		// TODO Auto-generated method stub
		double preimeter1=2*side;
		double perimeter2=preimeter1+base;
		System.out.println("Perimeter of the isometric triangle is:: "+ perimeter2);
	}

	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		
		System.out.println("Area of the isometric triangle is:: "+ 0.5*base*height);
		
	}

}
