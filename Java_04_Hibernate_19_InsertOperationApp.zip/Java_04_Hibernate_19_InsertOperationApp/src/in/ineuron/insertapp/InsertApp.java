package in.ineuron.insertapp;

import java.io.IOException;
import java.util.Scanner;



import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import in.ineuron.model.Student;
import in.ineuron.util.HibernateUtil;

public class InsertApp {
	
	
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		Session session=null;
		Transaction transaction=null;
		Scanner sc=null;
		boolean flag=false;
		
		Student student=new Student();
		try {
			
			
			session=HibernateUtil.getSession();
			if(session != null)
				transaction=session.beginTransaction();
			
			if(transaction != null) {
				sc=new Scanner(System.in);
				
				System.out.println("Enter the name of the student:: ");
				String studentName=sc.next();
				System.out.println("Enter the age of the student:: ");
				int studentAge=sc.nextInt();
				System.out.println("Enter the address of the student:: ");
				String studentAddress=sc.next();
				
				student.setSname(studentName);
				student.setAge(studentAge);
				student.setSaddress(studentAddress);
				
				session.saveOrUpdate(student);
				System.out.println(student.getStdid());
				flag=true;
				
			}
			
			
		}catch(HibernateException he) {
			System.out.println("Hibernate Exception found");
			he.printStackTrace();
		}catch(Exception e) {
			System.out.println("Exception found");
			e.printStackTrace();
		}finally {
			if(flag) {
				transaction.commit();
				System.out.println("Data is loaded to DB");
				
				int id=student.getStdid();
				Student insertedStudent=session.get(Student.class, id);
				System.out.print(insertedStudent);
				
				System.out.println();
			}else {
				transaction.rollback();
				System.out.println("Data could not be loaded to DB");
			}
			sc.close();
			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();
			System.out.println("Closing Session");
		}
	}

}
