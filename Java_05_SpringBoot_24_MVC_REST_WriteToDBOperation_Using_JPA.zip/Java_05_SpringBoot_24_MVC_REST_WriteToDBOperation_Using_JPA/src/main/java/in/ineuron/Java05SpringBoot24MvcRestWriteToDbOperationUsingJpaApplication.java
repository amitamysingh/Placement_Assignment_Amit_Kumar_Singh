package in.ineuron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Java05SpringBoot24MvcRestWriteToDbOperationUsingJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Java05SpringBoot24MvcRestWriteToDbOperationUsingJpaApplication.class, args);
	}

}
