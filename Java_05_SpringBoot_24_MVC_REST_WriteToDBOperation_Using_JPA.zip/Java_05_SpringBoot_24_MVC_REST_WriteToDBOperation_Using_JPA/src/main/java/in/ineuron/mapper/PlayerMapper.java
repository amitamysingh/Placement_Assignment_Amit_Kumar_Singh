package in.ineuron.mapper;

import in.ineuron.dto.PlayersDto;
import in.ineuron.model.Players;

public class PlayerMapper {
	
	public static Players mapToPlayers(PlayersDto playerDto) {
		return new Players(
				playerDto.getId(),
				playerDto.getName(),
				playerDto.getTeam(),
				playerDto.getAge(),
				playerDto.getEmail()
				);
	}
	
	public static PlayersDto mapToPlayersDto(Players player) {
		return new PlayersDto(
				player.getId(),
				player.getName(),
				player.getTeam(),
				player.getAge(),
				player.getEmail()
				);
	}

}
