package in.ineuron.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.ineuron.dto.PlayersDto;
import in.ineuron.service.IPlayerService;

@RestController
@RequestMapping("api/player")
public class Controller {

	@Autowired
	private IPlayerService service;
	
	@PostMapping
	public ResponseEntity<PlayersDto> createPlayer(@RequestBody PlayersDto playerDto){
		
		PlayersDto savedPlayer = service.createPlayers(playerDto);
		
		return new ResponseEntity<>(savedPlayer, HttpStatus.CREATED);
		
	}
}
