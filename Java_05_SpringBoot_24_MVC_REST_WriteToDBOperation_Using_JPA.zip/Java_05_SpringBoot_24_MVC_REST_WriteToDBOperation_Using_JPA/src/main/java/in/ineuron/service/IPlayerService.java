package in.ineuron.service;

import in.ineuron.dto.PlayersDto;

public interface IPlayerService {

	public PlayersDto createPlayers(PlayersDto dto);
}
