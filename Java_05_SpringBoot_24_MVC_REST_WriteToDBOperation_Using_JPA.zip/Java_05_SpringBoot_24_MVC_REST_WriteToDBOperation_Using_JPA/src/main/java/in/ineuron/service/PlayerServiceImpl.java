package in.ineuron.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.ineuron.dto.PlayersDto;
import in.ineuron.mapper.PlayerMapper;
import in.ineuron.model.Players;
import in.ineuron.repository.PlayersRepository;

@Service
public class PlayerServiceImpl implements IPlayerService{

	@Autowired
	private PlayersRepository repo;
	
	@Override
	public PlayersDto createPlayers(PlayersDto dto) {
		// TODO Auto-generated method stub
		
		Players player = PlayerMapper.mapToPlayers(dto);
		Players savedPlayer = repo.save(player);
		
		return PlayerMapper.mapToPlayersDto(savedPlayer);
	}
	
	

}
