package in.ineuron.main;
class ParentClass{
	
	int i;

	 ParentClass(){
		System.out.println("This is parent class constructor");
	}
	
	public ParentClass(int i) {
		this.i=i;
		System.out.println("This is parameterized parent class constructor with parameter i= "+i);
	}
	
	
}

class ChildClass extends ParentClass{
	
	
	ChildClass(){
		//If we do not use this(), constructor of Parent Class will be called by default
		//as super() is by default present in all the constructor
		System.out.println("This is child class constructor");
	}
	
	ChildClass(int i){
		//By default super() will be present in all the constructors,
		//and zero parameterized constructor will be called
		//hence, to call parameterized constructor we need to explicitly call parameterized constructor 
		//using super(i)
		super(i);
		System.out.println("This is parameterized child class constructor with parameter i= "+i);
		
	}
	
	
}


public class ConstructorMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ChildClass child=new ChildClass();//This will make a call to zero parameterized constructor
		
		ChildClass child2=new ChildClass(10); //This will make a call to parameterized child class constructor
	}

}
