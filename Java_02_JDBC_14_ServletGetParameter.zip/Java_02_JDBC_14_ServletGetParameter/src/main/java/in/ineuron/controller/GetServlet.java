package in.ineuron.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*
 * 
 * To run this program(from eclipse), we need to configure a tomcat server(preferably v9.0)
 * and we need to add servlet-api jar from apacheTomcat>>lib folder using configure build path
 *
 * (CSS can always be improved)
 * 
 */

@WebServlet("/getServlet")
public class GetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		
		String name=request.getParameter("userName");
		
		PrintWriter out=response.getWriter();
		
		out.println("<html><head><title>WelcomePage</title></head>");
		out.println("<body bgcolor='powderblue'><h1 style='color:purple; text-align:center;'><br><br><br>Welcome "+name+"</h1></body>");
		out.println("</html>");
		
		
	}
}
