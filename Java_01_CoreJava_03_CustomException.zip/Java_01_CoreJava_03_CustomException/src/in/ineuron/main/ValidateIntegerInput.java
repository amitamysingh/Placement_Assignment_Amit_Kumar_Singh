package in.ineuron.main;

import java.util.Scanner;

class NegativeIntegerException extends Exception{
		
}

public class ValidateIntegerInput {

	Scanner sc;
	int inputInteger;
	String isContinue;

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		
		ValidateIntegerInput intInput=new ValidateIntegerInput();
		intInput.validateInput();
		
		
	}
	
	public void validateInput() {
		try {	
			sc=new Scanner(System.in);
			System.out.print("Enter an integer:: ");
			inputInteger=sc.nextInt();
			
			if(inputInteger < 0) {
				throw new NegativeIntegerException();
			}else {
				System.out.println("The entered number is:: "+inputInteger);
				System.out.println("Do you want to continue:: ");
				 isContinue=sc.next();
				 if(isContinue.equalsIgnoreCase("Y")) {
					 validateInput();
				 }else {
					 System.exit(0);
				 }
			}
			
			}catch(NegativeIntegerException ne) {
				System.out.println("The number entered is negative, which is not acceptable");
		}
	}

}
