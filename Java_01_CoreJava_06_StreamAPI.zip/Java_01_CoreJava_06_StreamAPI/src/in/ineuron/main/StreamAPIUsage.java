package in.ineuron.main;

import java.util.List;
import java.util.stream.Collectors;
import java.util.ArrayList;

public class StreamAPIUsage {
	
	public static void main(String[] args) {
		ArrayList<Integer> al = new ArrayList<Integer>();
		al.add(36);
		al.add(56);
		al.add(7);
		al.add(12);
		al.add(23);
		al.add(95);
		al.add(68);
		
		//Printling original Arraylist
		System.out.println("Original ArrayList :: ");
		System.out.println(al);
		System.out.println();
		
		//Filtering out the even numbers in the ArrayList
		List<Integer> evenList = al.stream().filter( i -> i%2==0).collect(Collectors.toList());
		System.out.println("List of even numbers in the arraylist :: ");
		evenList.forEach(System.out::println);
		System.out.println();
		
		
		//Sorting the ArrayList
		List<Integer> sortedList = al.stream().sorted().collect(Collectors.toList());
		System.out.println("Sorted ArrayList :: ");
		sortedList.forEach(System.out::println);
	
	}

	
	
	
}
