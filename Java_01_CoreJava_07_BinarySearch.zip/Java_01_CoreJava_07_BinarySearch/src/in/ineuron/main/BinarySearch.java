package in.ineuron.main;


import java.util.Scanner;


public class BinarySearch {
	
	
	
	
	
	public static void main(String[] args) {
		
		int[] numbers= {12,23,27,34,45,56,67,78,89,90};
		int start=0;
		int end=numbers.length-1;
		
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter the target:: ");
		int target=sc.nextInt();
		int result=binarySearchMethod(numbers, start, end, target);
		if(result != -1) {
			System.out.println("Target found at index:: "+result);
		}else {
			System.out.println("Target entered does not exist in numbers array");

		}
		
		
	
	}
	
	public static int binarySearchMethod(int[] numbers, int start, int end, int target) {
		
		
		int mid=start+(end-start)/2;
		
		if(start<=end) {
			if(numbers[mid]<target) {
				start=mid+1;
				//Recursive approach, calling same method itself
				return binarySearchMethod(numbers, start, end, target);
			}else if(numbers[mid] > target) {
				
				end=mid-1;
				//Recursive approach, calling same method itself
				return binarySearchMethod(numbers, start, end, target);
								
			}else if(numbers[mid]== target) {
								
				return mid;
			}
		}return -1;
	}

}
