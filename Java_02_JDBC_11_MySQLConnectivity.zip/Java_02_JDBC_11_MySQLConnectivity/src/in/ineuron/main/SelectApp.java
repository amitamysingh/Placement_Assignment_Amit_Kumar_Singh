package in.ineuron.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectApp {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		//Steps to connect and retreive data from DB
		
		//1.Load and register the DB
		Class.forName("com.mysql.cj.jdbc.Driver");
		System.out.println("Loading the Driver");
		
		//2. Establish the connection
		String url="jdbc:mysql://localhost:3306/mydb";
		String username="root";
		String password="root@123";
		
		Connection connection=DriverManager.getConnection(url, username, password);
		System.out.println("Connection Object is created");
		
		//3. Create Statement Object and send query
		Statement statement=connection.createStatement();
		System.out.println("Statement object is created");
		
		//4. Execute Query
		String selectQuery="select sname,sage,saddress from student";
		ResultSet resultSet=statement.executeQuery(selectQuery);
		System.out.println("ResultSet object is created");
		System.out.println("sname\tsage\tsaddress");
		
		while(resultSet.next()) {
			String sname=resultSet.getString("sname");
			int sage=resultSet.getInt("sage");
			String saddress=resultSet.getString("saddress");
			System.out.println(sname+"\t"+sage+"\t"+saddress);
		}
		
		//5. Close Connection
		resultSet.close();
		statement.close();
		connection.close();
	}

}
