package in.ineuron.main;

import java.util.Scanner;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import in.ineuron.Util.HibernateUtil;
import in.ineuron.model.Student;

public class SelectApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Session session=null;
		int id;
		Scanner sc=null;
		try {
			session=HibernateUtil.getSession();
			sc=new Scanner(System.in);
			System.out.println("Enter the id of the student you want to search::");
			id=sc.nextInt();
			
			Student student=session.get(Student.class, id);
			if(student != null) {
				System.out.println(student);
			}else {
				System.out.println("Student not found with the id:: "+id);
			}
			
		}catch(HibernateException he) {
			System.out.println("Hibernate exception found");
			he.printStackTrace();
		}catch(Exception e) {
			System.out.println("Exception found");
			e.printStackTrace();
		}finally {
			sc.close();
			HibernateUtil.closeSession();
			HibernateUtil.closeSessionFactory();
		}
	}

}
