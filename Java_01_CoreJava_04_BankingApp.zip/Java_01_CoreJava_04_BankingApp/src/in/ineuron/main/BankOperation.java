package in.ineuron.main;

import java.util.Scanner;

public class BankOperation {
	
	private BankAccount account;
	BankOperation(BankAccount account){
		this.account=account;
	}
	long depositAmount;
	long withdrawalAmount;
	
	Scanner sc=new Scanner(System.in);
	
	
	
	public void selectAccountOperation(){
		int selectOperation;
		
		//BankOperations operation = new BankOperations();
		
		System.out.println("What do you want to do with your account?");
		System.out.println("Type '1' for deposit");
		System.out.println("Type '2' for withdrawal");
		System.out.println("Type '3' to check balance");
		selectOperation=sc.nextInt();
		
		if(selectOperation==1) {
			System.out.println("------------------------");
			deposit();
			
			System.out.println("------------------------");
		}
		else if(selectOperation==2) {
			System.out.println("------------------------");
			withdraw();
			System.out.println("------------------------");
			
		}else if(selectOperation==3) {
			System.out.println("------------------------");
			checkBalance();
			System.out.println("------------------------");
		}else {
			System.out.println("------------------------");
			System.out.println("Unknown input");
			System.out.println("------------------------");
			
		}
		
		isContinue();
	}
	
	public void isContinue() {
		String continueResponse;
		
		
		System.out.println("------------------------");
		System.out.println("Do you want to continue?:: Y/N");
		continueResponse=sc.next();
		
		if(continueResponse.equalsIgnoreCase("y")) {
			selectAccountOperation();
		}
		else if(continueResponse.equalsIgnoreCase("n")) {
			System.exit(0);
			
		}else {
			
			System.out.println("------------------------");
			System.out.println("Unknown input");
			isContinue();
		}
	}
	
	public void deposit() {
		
		System.out.println("Enter the amount to depost:: ");
		depositAmount=sc.nextInt();
		account.setAccountBalance(account.getAccountBalance()+depositAmount);
		
		System.out.println("Amount deposited successfully");
		System.out.println("New Balance is:: "+account.getAccountBalance());
	}
	
	public void withdraw() {
		
		System.out.println("Enter the amount to withdraw:: ");
		withdrawalAmount=sc.nextInt();
		account.setAccountBalance(account.getAccountBalance()-withdrawalAmount);
		System.out.println("Amount withdrawn successfully");
		System.out.println("New Balance is:: "+account.getAccountBalance());
	}
	
	public void checkBalance() {
		System.out.println("Your current Balance is:: "+account.getAccountBalance());
	}
	
}
