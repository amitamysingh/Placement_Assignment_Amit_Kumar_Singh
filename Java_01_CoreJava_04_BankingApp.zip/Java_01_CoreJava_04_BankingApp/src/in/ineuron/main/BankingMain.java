package in.ineuron.main;

import in.ineuron.main.BankAccount;
import in.ineuron.main.BankOperation;

import java.util.Scanner;


public class BankingMain {
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String accName;
		String accType;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the Account Holder name:: ");
		accName=sc.next();
		
		System.out.println("Enter the account type:: Savings/Current");
		accType=sc.next();
		
		BankAccount account=new BankAccount();
		
		
		account.setAccountHolderName(accName);
		account.setAccountType(accType);
		
		BankOperation operation=new BankOperation(account);
		operation.selectAccountOperation();
		
		
	}

}
