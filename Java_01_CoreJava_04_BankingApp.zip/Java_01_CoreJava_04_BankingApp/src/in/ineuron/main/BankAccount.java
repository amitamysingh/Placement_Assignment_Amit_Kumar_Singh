package in.ineuron.main;

import java.util.Scanner;

public class BankAccount {
	private String accountHolderName;
	private String accountType;
	private long accountBalance=0;
	
	Scanner sc=new Scanner(System.in);

	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	public long getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(long accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
	
}
